import requests
from behave import given, when, then

BASE_URL = "https://api.y.uno"

def get_headers():
    return {
        "public-api-key": "TO_BE_UPDATED",
        "private-secret-key": "TO_BE_UPDATED",
        "x-idempotency-key": "unique-id"
    }

@given("valid payment headers")
def step_headers(context):
    context.headers = get_headers()

@when("I create a purchase payment with minimal fields")
def step_purchase(context):
    payload = {"account_id": "TO_BE_UPDATED", "workflow": "DIRECT"}
    context.response = requests.post(f"{BASE_URL}/payments", json=payload, headers=context.headers)

@then("the payment response status should be 200")
def step_validate(context):
    assert context.response.status_code == 200
