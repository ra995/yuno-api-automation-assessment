def before_all(context):
    print("Test started")

def after_all(context):
    print("Test finished")
