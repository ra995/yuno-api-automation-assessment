# Yuno API Automation Assessment

Python + Behave framework for Yuno APIs.